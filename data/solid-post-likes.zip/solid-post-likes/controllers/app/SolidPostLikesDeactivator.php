<?php
namespace OACS\SolidPostLikes\Controllers\App;

if ( ! defined( 'WPINC' ) ) { die; }
/**
 * Fired during plugin deactivation
 */

 class SolidPostLikesDeactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	// public static function deactivate() {


	// }

}