<?php
namespace OACS\SolidPostLikes\Controllers\App;

if ( ! defined( 'WPINC' ) ) {die;}
/**
 * Fired during plugin activation
 * In park position. Not used
 */


class SolidPostLikesActivator {


	// public static function activate() {
	// }

}
