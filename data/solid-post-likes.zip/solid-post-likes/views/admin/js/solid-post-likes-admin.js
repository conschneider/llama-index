(function( $ ) {
	'use strict';

	/* Boring ey?
	* Like dancing skills? - https://www.youtube.com/watch?v=0XkO8SZJ4v0&list=PLLJp4Td5Nk6nXU0jq05DyIVv1BYchrSQx&index=8&t=0s
	* The second dancer kills it.
	*/


})( jQuery );
